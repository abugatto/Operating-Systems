#!/bin/bash

clear; clear;
make;
./P3 config_1.config