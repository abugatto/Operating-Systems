#!/bin/bash

clear; clear;
make;
./P2 config_1.config